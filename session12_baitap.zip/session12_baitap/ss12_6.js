let input = "cuộc SỐNG là những Chuyến Đi thú VỊ. "
function textInput(input) {
    input = input.trim();
    input = input.toLowerCase();
    let Arr = input.split(" ");
    for (let i = 0; i < Arr.length; i++) {
        Arr[i] = Arr[i].charAt(0).toUpperCase() + Arr[i].slice(1);
    }
    return Arr.join(" ")
}
console.log("Autput: ", textInput(input));