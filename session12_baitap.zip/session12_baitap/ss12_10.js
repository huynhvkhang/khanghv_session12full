
function maxsum(arr) {
    let max1 = arr[0];
    let max2 = arr[0];
    let start = 0,
        end = 0,
        temIndex = 0;
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > max1 + arr[i]) {
            max1 = arr[i];
            temIndex = i;
        }
        else { max1 += arr[i]; }
        if (max1 > max2) {
            max2 = max1;
            start = temIndex;
            end = i;
        }
    }
    let result = [];
    for (let i = start; i < end; i++) {
        result.push(arr[i]);
    }
    return result;
}
let arr = [-2, 1, -3, 4, -1,2,1,-5,4];
let result = maxsum(arr);
console.log("Mảng con có tổng lớn nhất: ",result);