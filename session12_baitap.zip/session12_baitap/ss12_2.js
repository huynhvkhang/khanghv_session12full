let numbers =["a","ab",3];
function text(check){
    let max =check[0]
for (let i=0;i<check.length;i++) {
    if(check[i].length>length){
        max=check[i]
    }
}
return max;
}
console.log("checkmax",text(numbers))