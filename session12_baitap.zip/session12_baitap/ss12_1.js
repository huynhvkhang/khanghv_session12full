
let a=+prompt("Nhập số thứ nhất");
let b=+prompt("Nhập số thứ hai");
let c=+prompt("Nhập số thứ ba");
function text(numbers){
    if (numbers%2==0) {
        console.log("là số chẵn",numbers)
    }
    else  { numbers%2!=0 
        console.log("là số lẻ",numbers)
    }
  
}

console.log(text(a))
console.log(text(b))
console.log(text(c))