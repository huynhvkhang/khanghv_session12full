let input = prompt("Nhập vào dữ liệu:");
let count = 0;
for (let i = 0; i < input.length; i++) {
    if (input.charAt(i) != '') {
        count++
    }
}
console.log("Chuỗi có", count, "ký tự");